#import pgzrun
WIDTH = 300
HEIGHT = 300
FPS = 30
TITLE = "Game"
# Auto Imported: JsForPy, Cookies, pygame, pgzero
# Importable, Sounds, json



def draw():
    screen.draw.text("Hello", center=(150,150), color="white")

def update(dt):
    pass


#pgzrun.go()