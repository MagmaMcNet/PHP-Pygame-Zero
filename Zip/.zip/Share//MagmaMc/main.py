print("a")
print("a")
print("a")

print("a")