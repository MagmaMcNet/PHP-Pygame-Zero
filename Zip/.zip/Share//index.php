<html>

<head>
    <!-- Primary Meta Tags -->
     <title>Pygame-Zero In Website</title>
    <meta name="title" content="Pygame-Zero In Website">
    <meta name="description" content="Pygame-Zero In Website">

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://python.magma-mc.net/">
    <meta property="og:title" content="Pygame-Zero In Website">
    <meta property="og:description" content="Pygame-Zero In Website">

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="https://python.magma-mc.net/">
    <meta property="twitter:title" content="Pygame-Zero In Website">
    <meta property="twitter:description" content="Pygame-Zero In Website">

    <!-- Import -->
    <script src="../Base/Skulpt/skulpt.min.js" type="text/javascript"></script>
    <script src="../Base/Skulpt/skulpt-stdlib.js" type="text/javascript"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.1/css/all.css" integrity="sha384-O8whS3fhG2OnA5Kas0Y9l3cfpmYjapjI0E4theH4iuMD+pLhbf6JI0jIMfYcK3yZ" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="../Base/main.js"></script>
	<script src="https://raw.githubusercontent.com/Stuk/jszip/master/dist/jszip.min.js"></script>
</head>

<body id="main" style="background: #1c1c1c; color: white; text-align: center;">
    <div>
        <header>
            <h1>Pygame Zero</h1>
        </header>
    </div>
    <div class="row">

    </div>
    <div class="col-md-2"></div>
    <div class="col-md-8">

        <div id="mycanvas">

        </div>
    </div>

    <div class="row">
        <div class="col-xs-6" id="editorsplace">
            <div id=editor style="border: 1px solid black; border: 0px;"></div>
        </div>
        <a class="btn btn-primary col-md-2" id="runbutton">Run code<span class="glyphicon glyphicon-play"></span></a>
    </div>
    <h2>
        Console
    </h2>
    <pre id="output" class="text-left" style="background-color: #141414; color:#f8f8f8; border: 0px;"></pre>

    </div>
    <div class="col-md-5"></div>
    <div class="col-md-5"></div>

    </div>
    <div class="col-md-2"></div>
    <div id="backdrop"></div>


    <script>
        document.getElementById("output").style['height'] = 0.6 * window.innerHeight;
        var UserID = new URLSearchParams(window.location.search).get('ID');
//#region libraries
        <?php echo file_get_contents("../Modules.js"); ?>
        
            'Sounds': {
                path: '../Share/'+UserID+'/Audio.js', // Sounds Module Used For pgzero
            },
        };
//#endregion

        function resetTarget() {
            var selector = Sk.TurtleGraphics.target;
            var target = typeof selector === "string" ? document.getElementById(selector) : selector;
            // clear canvas container
            while (target.firstChild) {
                target.removeChild(target.firstChild);
            }
            return target;
        }

        function createArrows(div) {
            var arrows = new Array(4);
            var direction = ["left", "right", "up", "down"];
            $(div).addClass("d-flex justify-content-center");
            for (var i = 0; i < 4; i++) {
                arrows[i] = document.createElement("span");
                div.appendChild(arrows[i]);
                $(arrows[i]).addClass("btn btn-primary btn-arrow");
                var ic = document.createElement("i");
                $(ic).addClass("fas fa-arrow-" + direction[i]);
                arrows[i].appendChild(ic);
            }


            var swapIcon = function(id) {
                $(arrows[id].firstChild).removeClass("fa-arrow-" + direction[id]).addClass("fa-arrow-circle-" + direction[id]);
            }

            var returnIcon = function(id) {
                $(arrows[id].firstChild).removeClass("fa-arrow-circle-" + direction[id]).addClass("fa-arrow-" + direction[id]);
            }

            $(arrows[0]).on('mousedown', function() {
                Sk.insertEvent("left");
                swapIcon(0);
            });
            $(arrows[0]).on('mouseup', function() {
                returnIcon(0);
            });
            $(arrows[1]).on('mousedown', function() {
                Sk.insertEvent("right");
                swapIcon(1);
            });
            $(arrows[1]).on('mouseup', function() {
                returnIcon(1);
            });
            $(arrows[2]).on('mousedown', function() {
                Sk.insertEvent("up");
                swapIcon(2);
            });
            $(arrows[2]).on('mouseup', function() {
                returnIcon(2);
            });
            $(arrows[3]).on('mousedown', function() {
                Sk.insertEvent("down");
                swapIcon(3);
            });
            $(arrows[3]).on('mouseup', function() {
                returnIcon(3);
            });

            $(document).keydown(function(e) {
                switch (e.which) {
                    case 37:
                        swapIcon(0);
                        break;
                    case 38:
                        swapIcon(2);
                        break;
                    case 39:
                        swapIcon(1);
                        break;
                    case 40:
                        swapIcon(3);
                        break;
                }
            });

            $(document).keyup(function(e) {
                switch (e.which) {
                    case 37:
                        returnIcon(0);
                        break;
                    case 38:
                        returnIcon(2);
                        break;
                    case 39:
                        returnIcon(1);
                        break;
                    case 40:
                        returnIcon(3);
                        break;
                }
            });
        };

        function printString(text) {
            var output = document.getElementById("output");
            text = text.replace(/</g, '&lt;');
            output.innerHTML = output.innerHTML + text;
        }

        function clearOutput() {
            var output = document.getElementById("output");
            output.innerHTML = '';
        }

        function builtinRead(x) {
            if (Sk.builtinFiles === undefined || Sk.builtinFiles["files"][x] === undefined)
                throw "File not found: '" + x + "'";
            return Sk.builtinFiles["files"][x];
        }


        function outf(text) {
            var output = document.getElementById("output");
            text = text.replace(/</g, '&lt;');
            output.innerHTML = output.innerHTML + text;
        }

        async function runCode() {
            const output = document.getElementById("output");
            output.innerHTML = '';
            
            Sk.configure({
                output: outf
            });
            
            Sk.main_canvas = document.createElement("canvas");
            Sk.quitHandler = () => {
                $('.modal').modal('hide');
            };
            
            
            const top = await fetchText("../Base/Mapper_Top.py");
            const bottom = await fetchText("../Base/Mapper_Bottom.py");
            const UserScript = await fetchText(UserID + "/main.py");
            var Program = UserScript;
            if (Program.indexOf("import pgzrun") !== -1)
            {
                
                CreateRunScreen(false);
                Program = top + UserScript + bottom;
            } else 
            CreateRunScreen(true);
            try 
            {
                await Sk.misceval.asyncToPromise(() => {
                    return Sk.importMainWithBody("<stdin>", false, Program, true);
                });
            } catch (error) 
            {
                error.traceback[0].lineno -= 1854;
                console.error(error + program);
                alert(error);
                location.reload();
            }
        }

async function fetchText(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to fetch ${url}: ${response.status} ${response.statusText}`);
  }
  return await response.text();
}


        (Sk.TurtleGraphics || (Sk.TurtleGraphics = {})).target = 'mycanvas';
        Sk.configure({
            read: builtinRead,
            output: printString
        });
        $("#runbutton").click(function() {
            runCode();
        });
    </script>
</body>

</html>